<?php
header("Location: input.php");
?>
