<?php
require_once "db.php";

if(isset($_POST["submit"]) && $_POST["submit"]!="") {
$usersCount = count($_POST["id"]);
for($i=0;$i<$usersCount;$i++) {
mysqli_query($con, "UPDATE patient set name='" . $_POST['name'][$i] . "', age='" . $_POST['age'][$i] . "',gender='" . $_POST["gender"][$i] . "',quarantine='" . $_POST["quarantine"][$i] . "', center='" . $_POST["center"][$i] . "', identifieddate='" . $_POST["identifieddate"][$i] . "' WHERE id='" . $_POST["id"][$i] . "'");
}
header("Location:test1.php");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Update patient details</title>

    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css?family=Roboto:400,700"
    />
    <!-- https://fonts.google.com/specimen/Roboto -->
    <link rel="stylesheet" href="css/fontawesome.min.css" />
    <!-- https://fontawesome.com/ -->
    <link rel="stylesheet" href="jquery-ui-datepicker/jquery-ui.min.css" type="text/css" />
    <!-- http://api.jqueryui.com/datepicker/ -->
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <!-- https://getbootstrap.com/ -->
    <link rel="stylesheet" href="css/templatemo-style.css">
    <!--
	Product Admin CSS Template
	https://templatemo.com/tm-524-product-admin
	-->
 
</head>
<body id="reportsPage">
    <div class="" id="home">
        <nav class="navbar navbar-expand-xl">
            <div class="container h-100">
                <a class="navbar-brand" href="">
                    <h1 class="tm-site-title mb-0">Admin</h1>
                </a>
                <button class="navbar-toggler ml-auto mr-0" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fas fa-bars tm-nav-icon"></i>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mx-auto h-100">
                        <li class="nav-item">
                            <a class="nav-link" href="http://localhost/webproject/Admin/Signup&login/home.php">
                                <i class="fas fa-home"></i>
                                Home
                                <span class="sr-only">(current)</span>
                            </a>
                        </li>
                        <li class="nav-item dropdown">

                            <a class="nav-link active dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
                                aria-haspopup="true" aria-expanded="false">
                                <i class="far fa-file-alt"></i>
                                <span>
                                    Patients <i class="fas fa-angle-down"></i>
                                </span>
                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="http://localhost/webproject/Admin/Add%20patient/input.php">Add patient</a>
                                <a class="dropdown-item" href="http://localhost/webproject/Admin/Add%20patient/test3.php">View patient</a>
                                <a class="dropdown-item" href="http://localhost/webproject/Admin/add%20patient/test2.php">Update patient</a>
                                <a class="dropdown-item" href="http://localhost/webproject/Admin/add%20patient/test1.php">Delete patient</a>
                            </div>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="http://localhost/webproject/Admin/Message/input.php">
                                <i class="fas fa-envelope"></i>
                                Mail
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="http://localhost/webproject/Admin/profile/home.php">
                                <i class="far fa-user"></i>
                                Profile
                            </a>
                        </li>
                        <li class="nav-item dropdown">
                        <a class="nav-link" href="http://localhost/Webproject/Admin&User/Front%20page.html">
                                <i class="fas fa-cog"></i>
                                Sign Out
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
    </nav>

  

    <div class="container tm-mt-big tm-mb-big">
      <div class="row">
        <div class="col-xl-9 col-lg-10 col-md-12 col-sm-12 mx-auto">
          <div class="tm-bg-primary-dark tm-block tm-block-h-auto">
            <div class="row">
              <div class="col-12">
                <h2 class="tm-block-title d-inline-block">Add Patient details</h2>
              </div>
            </div>
            <?php
$rowcount = count($_POST["patient"]);
for($i=0;$i<$rowcount;$i++) {
$result = mysqli_query($con, "SELECT * FROM patient WHERE id='" . $_POST["patient"][$i] . "'");
$row[$i]= mysqli_fetch_array($result);
?>
            <div class="row tm-edit-product-row">
              <div class="col-xl-6 col-lg-6 col-md-12">
                <form name=" frmuser" action="" class="tm-edit-product-form" method="post" enctype="multipart/form-data">
                  <div class="form-group mb-3">
                  <input type="hidden" name="id[]" class="txtField" value="<?php echo $row[$i]['id']; ?>">
                    <label for="name">Full Name</label>
                    <input
                      id="name"
                      name="name[]"
                      type="text"
                      value = "<?php echo $row[$i]['name']; ?>"
                      class="form-control validate"
                      required
                    />
                  </div>
                  <div class="form-group mb-3">
                    <label
                      for="age"
                      >Age</label
                    >
                    <input
                      id="age"
                      name="age[]"
                      type="text"
                      value = "<?php echo $row[$i]['age']; ?>"
                      class="form-control validate"
                      required
                    />
                  </div>
                  <div class="form-group mb-3">
                    <label
                      for="gender"
                      >Gender</label
                    >
                    <select
                      class="custom-select tm-select-accounts"
                      id="gender"
                      name="gender[]"
                      value = "<?php echo $row[$i]['gender']; ?>"

                    >
                      <option selected>Select category</option>
                      <option value="Male" name="Male">Male</option>
                      <option value="Female" name="Female">Female</option>
                      <option value="Other" name="Other">Other</option>
                    </select>
                  </div>
                  <div class="row">
                      <div class="form-group mb-3 col-xs-12 col-sm-6">
                          <label
                            for="identifieddate"
                            >Identified Date
                          </label>
                          <input
                            id="identifieddate"
                            name="identifieddate[]"
                            type="date"
                            class="form-control validate"
                            data-large-mode="true"
                          />
                        </div>
                        <div class="form-group mb-3 col-xs-12 col-sm-6">
                          <label
                            for="center"
                            >Tested center
                          </label>
                          <input
                            id="center"
                            name="center[]"
                            type="text"
                            value = "<?php echo $row[$i]['center']; ?>"
                            class="form-control validate"
                            required
                          />
                        </div>

                        <div class="form-group mb-3 col-xs-12 col-sm-6">
                    <label
                      for="quarantine"
                      >Quarantine report</label
                    >
                    <select
                      class="custom-select tm-select-accounts"
                      id="quarantine"
                      name="quarantine[]"
                      value = "<?php echo $row[$i]['quarantine']; ?>"

                    >
                      <option selected>Select category</option>
                      <option value="Positive" name="Positive">Positive</option>
                      <option value="Negative" name="Negative">Negative</option>
                      <option value="Under quarantine" name="Under quarantine">Under quarantine</option>
                    </select>
                  </div>
                  </div>
                  
              </div>
              <div class="col-12">
                <button type="submit" class="btn btn-primary btn-block text-uppercase" name="submit" value="submit">Update Patient</button>
              </div>
            </form>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php
    }
  
?>
          <script language="javascript" src="users.js" type="text/javascript"></script>
   <script src="js/jquery-3.3.1.min.js"></script>
    <!-- https://jquery.com/download/ -->
    <script src="jquery-ui-datepicker/jquery-ui.min.js"></script>
    <!-- https://jqueryui.com/download/ -->
    <script src="js/bootstrap.min.js"></script>
    <!-- https://getbootstrap.com/ -->
   
</body>
</html>
