
<?php
    $con = mysqli_connect("localhost","root","","web");
    if (mysqli_connect_errno()){
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
if(isset($_POST['submit'])){
  $nic = $_POST['nic'];

    $query = "UPDATE user SET name='$_POST[name]',gender='$_POST[gender]',age='$_POST[age]',contactno='$_POST[contactno]',address='$_POST[address]' WHERE nic = '$_POST[nic]'";
    $result = mysqli_query($con, $query);
    if ($result) {
      echo" <div class='container tm-mt-big tm-mb-big'>
      <div class='row'>
        <div class='col-12 mx-auto tm-login-col'>
          <div class='tm-bg-primary-dark tm-block tm-block-h-auto'>
            <div class='row'>
              <div class='col-12 text-center'>
                <h2 class='tm-block-title mb-4'>You are registered successfully<br>
                Click here to <a href='http://localhost/webproject/user/Signup&login/home.php'>Home</a></h2>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>";
 } else {
     echo " <div class='container tm-mt-big tm-mb-big'>
     <div class='row'>
       <div class='col-12 mx-auto tm-login-col'>
         <div class='tm-bg-primary-dark tm-block tm-block-h-auto'>
           <div class='row'>
             <div class='col-12 text-center'>
               <h2 class='tm-block-title mb-4'>Required fields are missing<br>
               Click here to <a href='home.php'>resubmit</a>again</h2>
             </div>
           </div>
         </div>
       </div>
     </div>
   </div>";
 }
      }else{
?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>User Profile</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,700">
    <!-- https://fonts.google.com/specimen/Roboto -->
    <link rel="stylesheet" href="css/fontawesome.min.css">
    <!-- https://fontawesome.com/ -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- https://getbootstrap.com/ -->
    <link rel="stylesheet" href="css/templatemo-style.css">
    <!--
	Product Admin CSS Template
	https://templatemo.com/tm-524-product-admin
	-->
</head>

<body id="reportsPage">
    <div class="" id="home">
        <nav class="navbar navbar-expand-xl">
            <div class="container h-100">
                <a class="navbar-brand" href="">
                    <h1 class="tm-site-title mb-0">User</h1>
                </a>
                <button class="navbar-toggler ml-auto mr-0" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fas fa-bars tm-nav-icon"></i>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mx-auto h-100">
                        <li class="nav-item">
                            <a class="nav-link" href="http://localhost/webproject/User/Signup&login/home.php">
                                <i class="fas fa-home"></i>
                                Home
                                <span class="sr-only">(current)</span>
                            </a>
                        </li>
                        <li class="nav-item dropdown">

                            <a class="nav-link  dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
                                aria-haspopup="true" aria-expanded="false">
                                <i class="far fa-file-alt"></i>
                                <span>
                                    User <i class="fas fa-angle-down"></i>
                                </span>
                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="http://localhost/webproject/User/Add%20user/input.php">Add user</a>
                                <a class="dropdown-item" href="http://localhost/webproject/User/Add%20user/test.php">View user</a>
                            </div>
                        </li>
                        <li class="nav-item">
								<a class="nav-link" href="http://localhost/webproject/User/review/input.php">
									<i class="far fa-star"></i>
									Review
								</a>
								</li>
                        <li class="nav-item">
                            <a class="nav-link active" href="http://localhost/webproject/User/profile/home.php">
                                <i class="far fa-user"></i>
                                Profile
                            </a>
                        </li>
                        <li class="nav-item dropdown">
                        <a class="nav-link" href="http://localhost/Webproject/Admin&User/Front%20page.html">
                                <i class="fas fa-cog"></i>
                                Sign Out
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
    </nav>
        
        <div class="container tm-mt-big tm-mb-big">
      <div class="row">
        <div class="col-xl-9 col-lg-10 col-md-12 col-sm-12 mx-auto">
          <div class="tm-bg-primary-dark tm-block tm-block-h-auto">
            <div class="row">
              <div class="col-12">
                <h2 class="tm-block-title d-inline-block">Profile settings</h2>
              </div>
            </div>
            <div class="row tm-edit-product-row">
              <div class="col-xl-6 col-lg-6 col-md-12">
                <form action="" class="tm-edit-product-form" method="post" enctype="multipart/form-data">
                  <div class="form-group mb-3">
                    <label for="name">Full Name</label>
                    <input
                      id="name"
                      name="name"
                      type="text"
                      class="form-control validate"
                      Placeholder = "Full name"
                      required
                    />
                  </div>
                  <div class="form-group mb-3">
                    <label for="nic">NIC</label>
                    <input
                      id="nic"
                      name="nic"
                      type="text"
                      class="form-control validate"
                      Placeholder = "NIC number"
                      required
                    />
                  </div>
                  <div class="form-group mb-3">
                    <label
                      for="age"
                      >Age</label
                    >
                    <input
                      id="age"
                      name="age"
                      type="text"
                      class="form-control validate"
                      Placeholder = "Age"
                      required
                    />
                  </div>
                  <div class="form-group mb-3">
                    <label
                      for="gender"
                      >Gender</label
                    >
                    <select
                      class="custom-select tm-select-accounts"
                      id="gender"
                      name="gender"
                    >
                      <option selected>Select category</option>
                      <option value="Male" name="Male">Male</option>
                      <option value="Female" name="Female">Female</option>
                      <option value="Other" name="Other">Other</option>
                    </select>
                  </div>
                  <div class="form-group mb-3">
                    <label for="contactno">Phone</label>
                    <input
                      id="contactno"
                      name="contactno"
                      type="text"
                      class="form-control validate"
                      Placeholder = "Phone number"
                      required
                    />
                  </div>
                  <div class="form-group mb-3">
                    <label for="address">Address</label>
                    <textarea
                      class="form-control validate"
                      name="address"
                      type="text"
                      rows="3"
                      Placeholder = "Address"
                      required
                    ></textarea>
                  </div>
                
              </div>
              <div class="col-12">
                <button name="submit" type="submit" class="btn btn-primary btn-block text-uppercase">Update details</button>
              </div>  
            </form>
            </div>
          </div>
        </div>
      </div>
</div>
<?php
    }
?>
    <script src="js/jquery-3.3.1.min.js"></script>
    <!-- https://jquery.com/download/ -->
    <script src="js/moment.min.js"></script>
    <!-- https://momentjs.com/ -->
    <script src="js/Chart.min.js"></script>
    <!-- http://www.chartjs.org/docs/latest/ -->
    <script src="js/bootstrap.min.js"></script>
    <!-- https://getbootstrap.com/ -->
    <script src="js/tooplate-scripts.js"></script>  
</body>
</html>